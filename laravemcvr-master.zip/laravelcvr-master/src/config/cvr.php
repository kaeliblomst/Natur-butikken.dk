<?php

return [

	'userid' => env('CVR_USERID', ''),
	'password' => env('CVR_PASSWORD', ''),

];
